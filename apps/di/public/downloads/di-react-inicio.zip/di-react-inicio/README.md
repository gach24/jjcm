# Material de inicio · di-react (GuitarLA)

Contenido:

- `index.html`: la página de GuitarLA en HTML semántico, **sin estilos**. Es el
  marcado que llevarás a React; el aspecto lo irás construyendo con Tailwind
  componente a componente.
- `design/`: el diseño objetivo, como referencia visual.
  - `desktop.png`: versión de escritorio.
  - `desktop-cart.png`: escritorio con el panel lateral del carrito abierto.
  - `mobile.png`: versión móvil (390 px).
  - `mobile-cart.png`: móvil con el panel del carrito abierto.
- `img/`: logotipo, icono del carrito, imagen de cabecera y las 12 guitarras.
  Se copia a `public/img/` del proyecto React.
- `data/db.ts`: catálogo de guitarras. Se copia a `src/data/db.ts`.

Las instrucciones completas están en los apuntes del módulo:
https://gach24.github.io/jjcm/di/units/react/01-starter-material/
